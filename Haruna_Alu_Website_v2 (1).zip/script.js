// placeholder for future interactive features
console.log('Haruna Alu site loaded');